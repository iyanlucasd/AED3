#  TABELA HASH EXTENSÍVEL

Implementação da tabela hash extensível para a disciplina Algoritmos e Estruturas de Dados 3 do curso de Ciência da computação da PUC Minas.

Esta tabela tem uma implementação ligeiramente diferente das tabelas tradicionais, em que contamos com as seguintes operações:

- create(C, V)
- V <- read(C)
- update(C, V)
- delete(C)

Nessas operações, usamos explicitamente uma chave (C) e um valor (V).

Neste projeto, porém, podemos armazenar qualquer tipo de objeto. Esse objeto precisa ter um atributo que será identificado como chave e que terá o seu hash calculado por meio do método hashCode(). Assim, nossos métodos serão os seguintes métodos:

- create(E)
- E <- read(C)
- update(E)
- delete(C)

Sendo E o elemento completo (contendo todos os dados) e C a chave numérica correspondente a esse elemento.

Para assegurar o funcionamento correto da tabela hash extensível, esse objeto deve implementar a interface RegistroHashExtensível.

*Implementado pelo Prof. Marcos Kutova*
*v1.1 - 2021*